#!/bin/bash -x
#alias task1="cp -f www/img/icon.png ../resources"
#alias task2="cp -f www/img/splash.png ../resources"
#alias proj="cd ../"
#cp -f img/icon.png ../resources
#cp -f img/splash.png ../resources
ionic platform add android
cordova plugin add com.rjfun.cordova.plugin.admob
#ionic state restore
ionic resources