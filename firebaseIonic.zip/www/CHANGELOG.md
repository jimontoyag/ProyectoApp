## 1.1.2 "bobby" (2016-05-16)

#### Enhancements

* **Admob:**  added admob compatibility.
* **Social Networks Auth** added login w/ Facebook, Google, Twitter